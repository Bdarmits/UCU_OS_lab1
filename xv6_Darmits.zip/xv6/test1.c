#include "types.h"
#include "stat.h"
#include "user.h"

int main(void){
	printf(1, "Testrun of program from xv6 DONE!!!\n");
	exit();
}
